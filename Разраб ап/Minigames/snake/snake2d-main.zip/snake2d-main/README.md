# snake2d
Простая игра змейка на JavaScript(без библиотек)

# Дополнительно
- Процесс создания [тут](https://youtu.be/TSdGHbI6veI)

> ![Screen 1](screen/welcome.png)